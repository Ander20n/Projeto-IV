const db = require("./app/config/db.config");

//const dados = await dadosTratados.create({  
//    HORA: 1200,
//    DC_NOME: 'OLINDA',
//    CD_ESTACAO: 'A015',
//    VL_LATITUDE: '456',
//    VL_LONGITUDE: '654',
//    TEM_MAX: 22.0,
//    PRE_MIN: 9.1,
//    VEN_VEL: 1.5,
//    CHUVA: 0
//});

exports.handler = async (event, context) => {

    const dadosTratados = db.dados;

    const output = event.records.map((record) => {

        try {
            let data = record.data;
            let buff = new Buffer(data, 'base64');
            let text = buff.toString('ascii');
            data.createdAt = Date.now();
            return JSON.parse(text);
        } catch (err) {
            
        }


    });

    await dadosTratados.bulkCreate(output);
    console.log('UHUUUU');
    return output;
};