module.exports = (sequelize, Sequelize) => {
	const DadosINMET = sequelize.define('dadosTratados', {
		HORA: {
			type: Sequelize.INTEGER
		},
		DC_NOME: {
			type: Sequelize.STRING
		},
		CD_ESTACAO: {
			type: Sequelize.STRING
		},
		VL_LATITUDE: {
			type: Sequelize.STRING
		},
		VL_LONGITUDE: {
			type: Sequelize.STRING
		},
		TEM_MAX: {
			type: Sequelize.FLOAT
		},
		PRE_MIN: {
			type: Sequelize.FLOAT
		},
		TEM_MIN: {
			type: Sequelize.FLOAT
		},
		VEN_VEL: {
			type: Sequelize.FLOAT
		},
		CHUVA: {
			type: Sequelize.FLOAT
		}
	},
		{
			timestamps: true
		}
	);
	return DadosINMET;
}