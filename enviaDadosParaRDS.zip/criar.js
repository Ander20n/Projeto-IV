const db = require('./app/config/db.config.js');
db.sequelize.sync().then(() => {
  console.log('Drop and Resync with { force: true }');
});