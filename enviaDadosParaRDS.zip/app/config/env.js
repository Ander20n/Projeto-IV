const env = {

    database: 'DADOS',
    username: 'admin',
    password: 'lzqld7n7el1OyNmGJsCg',
    host: 'tratardadosbd.cf7azvdl423r.us-east-1.rds.amazonaws.com',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
  };
   
  module.exports = env;